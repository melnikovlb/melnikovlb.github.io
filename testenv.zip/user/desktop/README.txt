--- What is this build? ---
This build is a light version of Windows 96.
It was made so you can test your apps in a clean envirement.


The original build was taken from Sysbox.
